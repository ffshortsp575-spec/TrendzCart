ShopKart Flipkart-style Package
==============================

What's inside:
- wordpress-theme/shopkart-lite/  -> Minimal WordPress theme (index.php contains the static homepage)
- static-site/                     -> Static HTML version (single file: index.html)
- README.md                         -> This file (instructions)

Important notes
---------------
1) The included WordPress theme is a minimal demo theme. It makes the static Flipkart-style homepage available as a WP theme.
   - To get full e-commerce features (real product database, add/edit products, carts, payments), you MUST install:
     * WooCommerce (free)
     * Dokan or WCFM Marketplace (if you want multi-vendor features)
   - After installing WooCommerce, set up products and connect payment gateways.

2) How to install the WordPress theme (on any WP site):
   - Login to WordPress admin -> Appearance -> Themes -> Add New -> Upload Theme
   - Upload the 'shopkart-lite.zip' theme (this package)
   - Activate theme
   - The homepage will display the demo static layout. To make it a real store, install WooCommerce and required plugins.

3) How to use as static site:
   - Upload static-site/index.html to any static hosting (InfinityFree, Netlify, GitHub Pages).
   - Static site DOES NOT have backend product management; use it for demo / landing pages.

4) Admin-only Add Product:
   - The demo includes a frontend admin "Add Product" modal for visual demo only. To make product add real:
     - Install WooCommerce and Dokan/WCFM.
     - Use Dokan's settings to disable vendor product add and keep it admin-only (per your request).
     - You can map the frontend fields to WooCommerce product fields via a developer or use WP plugins like WP All Import for bulk imports.

5) Free hosting recommendation:
   - InfinityFree (https://infinityfree.net) for a fully free setup (supports PHP + MySQL).
   - For static hosting: Netlify, GitHub Pages (free), Vercel.

6) If you want, I can:
   - Create the theme ZIP now and provide it for download (included).
   - OR convert this into a full WP child-theme with WooCommerce templates (this requires more time and custom coding).

Next steps (recommended)
------------------------
If you want a real working store with Admin-only product add and payments (100% no-code after setup):
1) Use InfinityFree or other free host, install WordPress.
2) Upload and activate this theme.
3) Install WooCommerce and Dokan/WCFM.
4) Configure Dokan to disable vendor product add (so only admin can add).
5) Use WooCommerce for product management (no coding).

If you want me to produce the ZIP and make it available to download, reply YES and I'll attach it.
