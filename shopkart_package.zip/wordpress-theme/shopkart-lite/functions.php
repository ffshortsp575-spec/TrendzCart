<?php
// Minimal functions.php to support basic WP features
function shopkart_enqueue_scripts() {
    // Tailwind is already loaded in HTML via CDN, but keeping wp_enqueue_style placeholder
    wp_enqueue_style('shopkart-style', get_stylesheet_uri());
}
add_action('wp_enqueue_scripts', 'shopkart_enqueue_scripts');
